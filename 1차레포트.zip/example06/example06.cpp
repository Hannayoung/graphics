#include "stdafx.h"
#include <GL/glut.h>
#include <STDLIB.H>	
#include <GL/gl.h>
#include <GL/glu.h>

GLboolean IsSphere = true;
GLboolean IsSmall = true;
GLboolean IsYes = true;
GLboolean IsColor = true;


int na = 1;

void MyDisplay() {
	
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0, 0.0,0.0);
	//Į��޴��� 2���� �ϰ� ���� ��
	/*
	if ((IsSphere) && (IsSmall)&&(IsColor)) {
			
		glColor3f(1.0, 1.0, 0.0);
		glutWireSphere(0.2, 15, 15);
	}
	else if ((IsSphere) && (IsSmall) && (!IsColor)) {
			
		glColor3f(0.0, 0.0, 1.0);
		glutWireSphere(0.2, 15, 15);
	}
	else if ((IsSphere) && (!IsSmall) && (IsColor)) {
			
		glColor3f(1.0, 1.0, 0.0);
		glutWireSphere(0.4, 15, 15);	
	}
	else if ((IsSphere) && (!IsSmall) && (!IsColor)) {
		
		glColor3f(0.0, 0.0, 1.0);
		glutWireSphere(0.4, 15, 15);
	}
	else if ((!IsSphere) && (IsSmall) && (IsColor)) {
			
		glColor3f(1.0, 1.0, 0.0);
		glutWireTorus(0.1, 0.3, 15, 20);
	}
	else if ((!IsSphere) && (IsSmall) && (!IsColor)) {
			
		glColor3f(0.0, 0.0, 1.0);
		glutWireTorus(0.1, 0.3, 15, 15);
	}
	else if ((!IsSphere) && (!IsSmall) && (IsColor)) {
			
		glColor3f(1.0, 1.0, 0.0);
		glutWireTorus(0.4, 0.6, 20, 20);
	}
	else if ((!IsSphere) && (!IsSmall) && (!IsColor)) {
			
		glColor3f(0.0, 0.0, 1.0);
		glutWireTorus(0.4, 0.6, 20, 20);	
	}
		
	*/
	if (na == 1) {
		if ((IsSphere) && (IsSmall)) {
		
			glColor3f(1.0, 1.0, 0.0);
			glutWireSphere(0.2, 15, 15);
		}
		else if ((IsSphere) && (!IsSmall)) {
			glColor3f(1.0, 1.0, 0.0);
			glutWireSphere(0.4, 15, 15);
		}
		else if ((!IsSphere) && (IsSmall)) {
			glColor3f(1.0, 1.0, 0.0);
			glutWireTorus(0.1, 0.3, 40, 20);
		}
		else if ((!IsSphere) && (!IsSmall)) {
			glColor3f(1.0, 1.0, 0.0);
			glutWireTorus(0.2, 0.5, 40, 20);
		}

	}
	if (na == 2) {
		if ((IsSphere) && (IsSmall)) {
		
			glColor3f(0.0, 0.0, 1.0);
			glutWireSphere(0.2, 15, 15);
		}
		else if ((IsSphere) && (!IsSmall)) {
			
			glColor3f(0.0, 0.0, 1.0);
			glutWireSphere(0.4, 15, 15);
		}
		else if ((!IsSphere) && (IsSmall)) {
			
			glColor3f(0.0, 0.0, 1.0);
			glutWireTorus(0.1, 0.3, 40, 20);
		}
		else if ((!IsSphere) && (!IsSmall)) {
			
			glColor3f(0.0, 0.0, 1.0);
			glutWireTorus(0.2, 0.5, 40, 20);
		}
		
	}
	if (na == 3) {
		if ((IsSphere) && (IsSmall)) {
			
			glColor3f(0.0, 1.0, 0.0);
			glutWireSphere(0.2, 15, 15);
		}
		else if ((IsSphere) && (!IsSmall)) {
		
			glColor3f(0.0, 1.0, 0.0);
			glutWireSphere(0.4, 15, 15);
		}
		else if ((!IsSphere) && (IsSmall)) {
			
			glColor3f(0.0, 1.0, 0.0);
			glutWireTorus(0.1, 0.3, 40, 20);
		}
		else if ((!IsSphere) && (!IsSmall)) {
			
			glColor3f(0.0, 1.0, 0.0);
			glutWireTorus(0.2, 0.5, 40, 20);
		}

	}
	glFlush();
	
}

void MyMainMenu(int entryID) {
	if (entryID == 1)
		IsSphere = true;                //���� �׸���
	else if (entryID == 2)
		IsSphere = false;               //��ȯü �׸���
	else if (entryID == 3)
		exit(0);                        //���α׷� ����
	glutPostRedisplay();
}

void MySubMenu(int entryID) {
	if (entryID == 1)
		IsSmall = true;                 //���� ũ��� �׸���
	else if (entryID == 2)
		IsSmall = false;                //ū ũ��� �׸���
	glutPostRedisplay();
}
//Į�� �޴��� 2���θ� �ϰ� ������
/*void MyColorMenu(int entryID) {

	if (entryID == 1) {

		IsColor = true;
	}
	if(entryID == 2) {
		IsColor = false;
	}
	glutPostRedisplay();

}*/
void MyColorMenu(int entryID) {

	if (entryID == 1) {

		na = 1;
	}
	if (entryID == 2) {
		na = 2;
	}
	if (entryID == 3)
	{
		na = 3;
	}
	glutPostRedisplay();

}


void MyExitMenu(int entryID) {
	if (entryID == 1)
	{
		exit(0);
	}
	else
		glutDisplayFunc(MyDisplay);
	glutPostRedisplay();

}
void MyReshape(int NewWidth, int NewHeight) {
	glViewport(0, 0, NewWidth, NewHeight);
	GLfloat WidthFactor = (GLfloat)NewWidth / (GLfloat)300;
	GLfloat HeightFactor = (GLfloat)NewHeight / (GLfloat)300;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0 * WidthFactor, 1.0 * WidthFactor,
		-1.0 * HeightFactor, 1.0 * HeightFactor, -1.0, 1.0);
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB);
	glutInitWindowSize(300, 300);
	glutInitWindowPosition(510, 250);
	glutCreateWindow("Menu Callback2");

	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
	
	
	GLint MySubExitMenuID = glutCreateMenu(MyExitMenu);
	glutAddMenuEntry("Yes", 1);
	glutAddMenuEntry("No", 2);
	GLint MySubColorMenuID = glutCreateMenu(MyColorMenu);
	glutAddMenuEntry("Yellow", 1);
	glutAddMenuEntry("Blue", 2);
	glutAddMenuEntry("Green", 3); //Į��޴��� 2���� �ϰ����� �� ����.
	GLint MySubMenuID = glutCreateMenu(MySubMenu);
	glutAddMenuEntry("Small One", 1);
	glutAddMenuEntry("Big One", 2);
	GLint MyMainMenuID = glutCreateMenu(MyMainMenu);
	glutAddMenuEntry("Draw Sphere", 1);
	glutAddMenuEntry("Draw Torus", 2);
	glutAddSubMenu("Change Size", MySubMenuID);
	glutAddSubMenu("Change Color", MySubColorMenuID);
	glutAddSubMenu("Exit", MySubExitMenuID);
	
	
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutDisplayFunc(MyDisplay);
	glutReshapeFunc(MyReshape);
	glutMainLoop();
	return 0;
}
