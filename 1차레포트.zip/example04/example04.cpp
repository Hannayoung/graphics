#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>

typedef struct Point
{
	int x;
	int y;
}Point;

Point p[2];
int Count = 0;

GLvoid MyDisplay() {
	
	
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex3f(-0.5,-0.5 , 0.0);
	glVertex3f(0.5, -0.5, 0.0);
	glVertex3f(0.5, 0.5, 0.0);
	glVertex3f(-0.5, 0.5, 0.0);
	glEnd();


	if (Count == 2)
	{
		glColor3f(0.0f, 0.0f, 0.0f);
		glBegin(GL_LINES);
		glVertex2d(p[0].x, 400 - p[0].y);
		glVertex2d(p[1].x, 400 - p[1].y);
		glEnd();
	}
	glFlush();
}
GLvoid MyReshape(int a, int b)
{
	glOrtho(0.0, (GLfloat)a, 0.0, (GLfloat)b, -0.0, 1.0);
}

GLvoid MyMouseClick(int Button, int State, int X, int Y) {
	//���� ��ư�� ������
	if (Button == GLUT_LEFT_BUTTON && State == GLUT_DOWN)
	{
		Count = 1;
		p[0].x = X;
		p[0].y = Y;//���� ��ǥ ����
	}

	//���� ��ư�� �������
	if (Button == GLUT_LEFT_BUTTON && State == GLUT_UP)
	{
		Count = 2;//��ư�� �������� �˸�
		p[1].x = X;
		p[1].y = Y;//���� ��ǥ ����
		glutPostRedisplay();//ȭ���� ����
	}
}

void main(int argc, char* argv[]) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(500, 150);
	glutCreateWindow("Draw Line");
	glClearColor(1.0, 1.0, 1.0,1.0);
	glutDisplayFunc(MyDisplay);
	glutReshapeFunc(MyReshape);
	glutMouseFunc(MyMouseClick);
	
	glutMainLoop();
	
}

