#include "stdafx.h"
#include <GL/glut.h>
#include<STDLIB.H>	
#include <GL/gl.h>
#include <GL/glu.h>
int gl = 1;
void MyDisplay() {
	glClearColor(1.0, 1.0, 1.0, 1.0);
	
	glColor3f(0.5, 0.3, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
	switch (gl)
	{
		case 1:
		{
			glColor3f(0.5, 0.0, 0.0);
			glutWireSphere(0.5, 12, 20);
			break;
		}
		case 2:
		{
			glColor3f(0.0, 0.5, 0.5);
			glutWireTorus(0.2, 0.5, 10, 10);
			break;
		}

		case 3:
		{
			glColor3f(0.5, 0.5, 0.0);
			glutWireCone(0.5, 0.5 , 10, 10);
			break;
		}
		default:
			break;

	}
	glFlush();

}

void MyKeyboard(unsigned char KeyPressed, int X, int Y) {
	switch (KeyPressed) {
	case 'Q':
		exit(0); break;
	case 'e':
		exit(0); break;
	case 'q':
		exit(0); break;
	case 27:                //'esc' Ű�� �ƽ�Ű �ڵ� ��
		exit(0); break;
	case '1':
		gl = 1; break;
	case '2':
		gl = 2; break;
	case '3':
		gl = 3; break;
	default :
		break;
	}
	glutPostRedisplay();
}
void MyReshape(int NewWidth, int NewHeight) {
	glViewport(0, 0, NewWidth, NewHeight);
	GLfloat WidthFactor = (GLfloat)NewWidth / (GLfloat)500;
	GLfloat HeightFactor = (GLfloat)NewHeight / (GLfloat)500;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0 * WidthFactor, 1.0 * WidthFactor,
		-1.0 * HeightFactor, 1.0 * HeightFactor, -1.0, 1.0);
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(440, 100);
	glutCreateWindow("keyboard call back");
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
	glutDisplayFunc(MyDisplay);
	glutKeyboardFunc(MyKeyboard);
	glutReshapeFunc(MyReshape);
	glutMainLoop();
	return 0;
}
