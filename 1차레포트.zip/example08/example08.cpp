#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <STDLIB.H>

int gl = 1;
GLboolean IsRotation = true;
GLfloat cubeRotate = 0.0;
GLfloat cuxRotate = 0.0;
GLfloat cuyRotate = 0.0;
GLfloat cuzRotate = 0.0;
GLfloat Delta = 0.0;


void MyDisplay() {

	glClearColor(1.0, 1.0, 1.0, 1.0);

	glColor3f(0.8, 0.3, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glRotatef(cuxRotate, 1.0f, 0.0f, 0.0f);
	glRotatef(cuyRotate, 0.0f, 1.0f, 0.0f);
	glRotatef(cuzRotate, 0.0f, 0.0f, 1.0f);
	
	
	if (gl== 2) {
		cuyRotate += 5;
	}
	if (gl == 3)
	{
		cuzRotate += 5;
	}
	if (gl == 4)
	{
		cuxRotate -= 5;
	}
	if (gl == 5)
	{
		cuyRotate -= 5;
	}
	if (gl == 6)
	{
		cuzRotate -= 5;
	}
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glRotatef(cubeRotate, 1.0f, 1.0f, 1.0f);
	glutWireCube(0.5);
	glFlush();
	glutSwapBuffers();
}

void RotateCube(int value) {
	if(IsRotation)
	 cubeRotate += 1.0;
	glutPostRedisplay();
	glutTimerFunc(40, RotateCube, 1);
	
}

void MyMainMenu(int entryID){

	if (entryID == 1) {

		gl = 1;
	}
	if (entryID == 2) {
		gl = 2;
	}
	if (entryID == 3)
	{
		gl = 3;
	}
	if (entryID == 4)
	{
		gl = 4;
	}
	if (entryID == 5)
	{
		gl = 5;
	}
	if (entryID == 6)
	{
		gl = 6;
	}
	glutPostRedisplay();

}
void MyExitMenu(int entryID) {
	if (entryID == 1)
	{
		exit(0);
	}
	else
		glutDisplayFunc(MyDisplay);
	glutPostRedisplay();

}

void MyReshape(int NewWidth, int NewHeight) {
	glViewport(0, 0, NewWidth, NewHeight);
	GLfloat WidthFactor = (GLfloat)NewWidth / (GLfloat)300;
	GLfloat HeightFactor = (GLfloat)NewHeight / (GLfloat)300;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0 * WidthFactor, 1.0 * WidthFactor,
		-1.0 * HeightFactor, 1.0 * HeightFactor, -1.0, 1.0);
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
	glutInitWindowSize(300, 300);
	glutInitWindowPosition(520, 250);
	glutCreateWindow("Timer Call Back");
	glMatrixMode(GL_PROJECTION);

	
	glLoadIdentity();
	glutDisplayFunc(MyDisplay);
	glOrtho(-1.0, 1.0, -1.0, 1.0, 1.0, -1.0);
	
	GLint MySubExitMenuID = glutCreateMenu(MyExitMenu);
	glutAddMenuEntry("Yes", 1);
	glutAddMenuEntry("No", 2);
	GLint MyMainMenuID = glutCreateMenu(MyMainMenu);
	glutAddMenuEntry("x_rotation_plus", 1);
	glutAddMenuEntry("y_rotation_plus", 2);
	glutAddMenuEntry("z_rotation_plus", 3);
	glutAddMenuEntry("x_rotation_minus", 4);
	glutAddMenuEntry("y_rotation_minus", 5);
	glutAddMenuEntry("z_rotation_minus", 6);

	glutAddSubMenu("Exit", MySubExitMenuID);

	glutAttachMenu(GLUT_RIGHT_BUTTON);
	
	glutReshapeFunc(MyReshape);
	glutTimerFunc(40, RotateCube, 1);
	
	
	glutMainLoop();
	return 0;
}
