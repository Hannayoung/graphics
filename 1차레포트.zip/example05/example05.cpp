#include "stdafx.h"
#include <GL/glut.h>
#include <STDLIB.H>
#include <GL/gl.h>
#include <GL/glu.h>

int na = 1;
GLboolean IsSphere = true;

void MyDisplay() {
	
	glClear(GL_COLOR_BUFFER_BIT);
	
	if ((IsSphere) && (na))
	{
		glColor3f(0.0, 1.0, 1.0);
		glutWireSphere(0.2, 15, 15);
	}//����޴� glutWireCone(0.5, 0.5, 10, 10);
	else if ((IsSphere) && (!na))
	{
		glColor3f(0.0, 1.0, 1.0);
		glutWireSphere(0.5, 40, 40);
	}
	else if ((!IsSphere) && (na))
	{
		glColor3f(0.5, 0.0, 0.3);
		glutWireTorus(0.1, 0.3, 40, 20);
		
	}
	else
	{
		glColor3f(0.5, 0.0, 0.3);
		glutWireTorus(0.3, 0.5, 45, 25);
	}
	
	glFlush();
}

void MyMainMenu(int entryID) {
	if (entryID == 1)
		IsSphere = true;
	else if (entryID == 2)
		IsSphere = false;
	else
		exit(0);
	glutPostRedisplay();
}
void MySubMenu(int entryID) {
	if (entryID == 1)
		na = true;
	else if (entryID == 2)
		na = false;
	
	glutPostRedisplay();
}

void MyReshape(int NewWidth, int NewHeight) {
	glViewport(0, 0, NewWidth, NewHeight);
	GLfloat WidthFactor = (GLfloat)NewWidth / (GLfloat)500;
	GLfloat HeightFactor = (GLfloat)NewHeight / (GLfloat)500;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0 * WidthFactor, 1.0 * WidthFactor,
		-1.0 * HeightFactor, 1.0 * HeightFactor, -1.0, 1.0);
}


int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(500, 150);
	glutCreateWindow("menu call back");

	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);

	GLint MySubMenuID = glutCreateMenu(MySubMenu);
	glutAddMenuEntry("small", 1);
	glutAddMenuEntry("big", 2);


	GLint MyMainMenuID = glutCreateMenu(MyMainMenu);
	glutAddMenuEntry("Draw Sphere", 1);
	glutAddMenuEntry("Draw Torus", 2);
	
	glutAddSubMenu("another ", MySubMenuID);
	glutAddMenuEntry("Exit", 3);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutDisplayFunc(MyDisplay);
	glutReshapeFunc(MyReshape);
	glutMainLoop();
	return 0;
}

