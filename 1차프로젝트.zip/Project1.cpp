#include "stdafx.h"
#include <windows.h>
#include <MMSystem.h>
#include <gl/glut.h>
#include <gl/gl.h>
#include <gl/GLU.h>
#include <math.h>

#define RUN 1
#define JAP 2
#define ROCKET 3
#define YUNA 4
#define SPIN 5
#define EXIT 7

static int x = 0;
static double time = 0;
static double time2 = 0;
static double time3 = 0;
static double time4 = 0;
static double time6 = 0;

GLfloat R_Arm_x = 0;
GLfloat R_Arm_y = 0;
GLfloat L_Arm_x = 0;
GLfloat L_Arm_y = 0;
GLfloat R_Leg_x = 0;
GLfloat R_Leg_y = 0;
GLfloat L_Leg_x = 0;
GLfloat L_Leg_y = 0;
GLfloat R = 0;
GLfloat R2 = 0;

GLUquadricObj* cyl;

int a = 0;
int b = 0;
int c = 0;

static int flag = 0;
static int key = 0;

void glInit()
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glEnable(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	GLfloat ambientLight[] = { 0.3f, 0.3f, 0.3f, 1.0f };
	GLfloat diffuseLight[] = { 0.7f, 0.7f, 0.7f, 1.0f };
	GLfloat specular[] = { 0.7f, 0.7f, 0.7f, 1.0f };
	GLfloat specref[] = { 0.7f, 0.7f, 0.7f, 1.0f };
	GLfloat position[] = { 0.7f, 0.7f, 0.7f, 1.0f };
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT0, GL_POSITION, position);
	glEnable(GL_LIGHT0);
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glMateriali(GL_FRONT, GL_SHININESS, 128);
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
}

void Draw_Color(int i)
{
	if (i == RUN)
	{
		glColor3f(0.0, 1.0, 0.0);
	}
	else if (i == JAP)
	{
		glColor3f(1.0, 1.0, 0.0);
	}
	else if (i == ROCKET)
	{
		glColor3f(0.0, 1.0, 1.0);
	}
	else if (i == YUNA)
	{
		glColor3f(1.0, 0.0, 1.0);
	}
	else if (i == SPIN)
	{
		glColor3f(0.8, 0.5, 0.6);
	}
	else if (i == EXIT)
	{
		glColor3f(0.2, 0.2, 0.2);
	}
}

void Change_Wire_Or_Solid(int i)
{
	if (flag == 1)
	{
		gluQuadricDrawStyle(cyl, GLU_LINE);
	}
}

void DrawL_Arm(int x, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glRotatef(x, a, b, c);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glTranslatef(0.25, 0.0, 0.0);
	glRotatef(15.0, 0.0, 1.0, 0.0);
	Change_Wire_Or_Solid(flag);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 50, 1);

}


void DrawL_Hand(int y, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glTranslatef(0.0, 0.0, 0.22);
	glRotatef(y, a, b, c);
	Change_Wire_Or_Solid(flag);
	if (key == YUNA)
	{
		gluCylinder(cyl, 0.05, 0.02, 0.2, 15, 1);
	}
	else
		gluCylinder(cyl, 0.05, 0.05, 0.2, 15, 1);
	glPopMatrix();
}

void DrawL_HandRocket()
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glTranslatef(0, 0, R);
	Change_Wire_Or_Solid(flag);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 50, 1);
	glPopMatrix();
}

void DrawR_Arm(int x, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glRotatef(x, a, b, c);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glTranslatef(-0.25, 0.0, 0.0);
	glRotatef(-15.0, 0.0, 1.0, 0.0);
	Change_Wire_Or_Solid(flag);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 50, 1);

}

void DrawR_Hand(int y, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glTranslatef(0.0, 0.0, 0.22);
	glRotatef(y, a, b, c);
	Change_Wire_Or_Solid(flag);
	if (key == YUNA)
	{
		gluCylinder(cyl, 0.05, 0.02, 0.2, 50, 1);
	}
	else
		gluCylinder(cyl, 0.05, 0.05, 0.2, 50, 1);
	glPopMatrix();
}
void DrawR_HandRocket()
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glTranslatef(0, 0, R2);
	Change_Wire_Or_Solid(flag);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 50, 1);
	glPopMatrix();
}

void DrawBody(int x, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glRotatef(x, a, b, c);
	Change_Wire_Or_Solid(flag);
	gluCylinder(cyl, 0.2, 0.2, 0.45, 50, 1);
	glPopMatrix();
}

void DrawL_Legs(int x, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glTranslatef(0.1, 0.0, 0.42);
	glRotatef(x, a, b, c);
	Change_Wire_Or_Solid(flag);
	gluCylinder(cyl, 0.05, 0.05, 0.15, 50, 1);

}

void DrawL_foot(int y, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glTranslatef(0.0, 0.0, 0.18);
	glRotatef(y, a, b, c);
	Change_Wire_Or_Solid(flag);
	if (key == YUNA)
	{
		gluCylinder(cyl, 0.05, 0.03, 0.2, 50, 1);
	}
	else
		gluCylinder(cyl, 0.05, 0.05, 0.2, 50, 1);
	glPopMatrix();
}

void DrawR_Legs(int x, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glTranslatef(-0.1, 0.0, 0.42);
	glRotatef(x, a, b, c);
	Change_Wire_Or_Solid(flag);
	gluCylinder(cyl, 0.05, 0.05, 0.15, 50, 1);

}

void DrawR_foot(int y, int a, int b, int c)
{
	glPushMatrix();
	Draw_Color(key);
	cyl = gluNewQuadric();
	glTranslatef(0.0, 0.0, 0.18);
	glRotatef(y, a, b, c);
	Change_Wire_Or_Solid(flag);
	if (key == YUNA)
	{
		gluCylinder(cyl, 0.05, 0.03, 0.2, 15, 1);
	}
	else
		gluCylinder(cyl, 0.05, 0.05, 0.2, 15, 1);
	glPopMatrix();
}

void DrawNeck()
{
	glPushMatrix();
	glColor3f(1.0, 1.0, 1.0);
	cyl = gluNewQuadric();
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glTranslatef(0.0, 0.0, -0.045);
	Change_Wire_Or_Solid(flag);
	gluCylinder(cyl, 0.2, 0.2, 0.025, 100, 1);
	glPopMatrix();
}

void DrawGround()
{
	Draw_Color(flag);
	glTranslatef(0.0, -2.73, 0.0);
	glRotatef(45.0, 0, 1, 0);
	glRotatef(0.0 + time4 - 15, 0.0, 0.0, 1);
	Change_Wire_Or_Solid(flag);
	gluSphere(cyl, 2.5, 30, 90);
}

void StopGround()
{
	Draw_Color(flag);
	glTranslatef(0.0, -2.73, 0.0);
	Change_Wire_Or_Solid(flag);
	gluSphere(cyl, 2.5, 30, 90);
}

void DrawHead()
{

	glTranslatef(0.0, 0.02, 0.0);
	glPushMatrix();
	cyl = gluNewQuadric();
	Change_Wire_Or_Solid(flag);
	Draw_Color(key);
	gluSphere(cyl, 0.20, 30, 10);

	//���� �Ա׸���
	glRotatef(90.0, 1.0, 0.0, 0.0);

	glTranslatef(-0.16, 0.0, -0.22);
	gluCylinder(cyl, 0.005, 0.008, 0.1, 3, 1);
	glPopMatrix();
	glPushMatrix();

	//������ �Ա׸���
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glTranslatef(0.16, 0.0, -0.22);
	glRotatef(-35.0, 0.0, 1.0, 0.0);
	gluCylinder(cyl, 0.005, 0.008, 0.1, 3, 1);
	glPopMatrix();
	glPushMatrix();

	//���� �� �׸���
	glTranslatef(-0.1, 0.1, 0.13);
	glColor3f(0.0, 0.0, 0.0);
	gluSphere(cyl, 0.03, 10, 10);
	glPopMatrix();
	glPushMatrix();

	//������ �� �׸���
	glTranslatef(0.1, 0.1, 0.13);
	gluSphere(cyl, 0.03, 10, 10);
	glPopMatrix();
}


void DrawAndroid()
{
	DrawBody(0, 0, 0, 0);
	DrawNeck();
	DrawHead();
	DrawR_Arm(R_Arm_x, 1, 0, 0);
	if (key == ROCKET)
	{
		DrawR_HandRocket();
	}
	else
		DrawR_Hand(R_Arm_y, 1, 0, 0);
	DrawL_Arm(L_Arm_x, 1, 0, 0);
	if (key == ROCKET)
		DrawL_HandRocket();
	else
		DrawL_Hand(L_Arm_y, 1, 0, 0);
	DrawL_Legs(L_Leg_x, 1, 0, 0);
	DrawL_foot(L_Leg_y, 1, 0, 0);
	DrawR_Legs(R_Leg_x, 1, 0, 0);
	DrawR_foot(R_Leg_y, 1, 0, 0);

}


void Run()
{
	sndPlaySound(TEXT("C:\\sample1.wav"), SND_ASYNC | SND_NOSTOP);
	glLoadIdentity();
	L_Arm_x = sin(time) * 80;
	R_Arm_x = -L_Arm_x;
	R_Arm_y = -fabs(sin(time) * 60 + 50);

	L_Arm_y = -fabs(-sin(time) * 60 + 50);
	R_Leg_y = fabs(-sin(time) * 30 - 30);
	L_Leg_y = fabs(sin(time) * 30 - 30);
	R_Leg_x = sin(time) * 60;
	L_Leg_x = -R_Leg_x;

	cyl = gluNewQuadric();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);

	DrawGround();
	glLoadIdentity();

	//�κ��� �޸��鼭 �յ� �������� ǥ��
	glRotatef(-230.0, 0, 1, 0);
	glRotatef(fabs(sin(time) * 16), 1, 0, 0);
	glRotatef(sin(time) * 16, 0, 1, 0);

	//�κ��� �޸��鼭 ������ ������ ǥ��
	float d = 0;
	d = fabs(sin(time)*0.08);
	glPushMatrix();
	glTranslatef(0.0, d, 0);
	glTranslatef(0.0, 0.5, 0.0);
	DrawAndroid();
	glutSwapBuffers();
}

//���� ���� ��
void Jap()
{
	sndPlaySound(TEXT("C:\\sample3.wav"), SND_ASYNC | SND_NOSTOP);
	glLoadIdentity();
	L_Arm_x = (-40) + sin(time) * 60;
	R_Arm_x = (-80) - L_Arm_x;
	R_Arm_y = -fabs(cos(time2) * 80);

	L_Arm_y = -fabs(-cos(time2) * 80);
	R_Leg_y = fabs(-sin(time) * 30 - 20);

	L_Leg_y = fabs(sin(time) * 30 - 20);
	R_Leg_x = sin(time) * 30;

	L_Leg_x = -R_Leg_x;

	cyl = gluNewQuadric();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);

	DrawGround();
	glLoadIdentity();
	glRotatef(-230.0, 0, 1, 0);
	glRotatef(sin(time) * 10, 0, 0, 1);

	//�κ��� ���� �������� ���� ǥ��
	float e = 0;
	e = fabs(sin(time2)*0.085);
	glPushMatrix();
	glTranslatef(0.0, e, 0);
	glTranslatef(0.0, 0.5, 0.0);
	DrawAndroid();
	glutSwapBuffers();
}

void ex()
{
	sndPlaySound(TEXT("C:\\sample5.wav"), SND_ASYNC | SND_NOSTOP);
	glLoadIdentity();

	L_Arm_x = (-40) + sin(time2) * 60;
	R_Arm_x = (-80) - L_Arm_x;
	R_Arm_y = -fabs(cos(time2) * 10);
	L_Arm_y = -fabs(-cos(time2) * 10);
	R_Leg_y = fabs(-sin(time) * 30 - 30);
	L_Leg_y = fabs(sin(time) * 30 - 30);
	R_Leg_x = sin(time) * 60;
	L_Leg_x = -R_Leg_x;

	cyl = gluNewQuadric();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();
	glRotatef(-180, 0, 1, 0);
	glRotatef(time6, 0, 0, 1);
	glScalef(0.4 / (sin(time3)), 0.4 / (sin(time3)), 0.4 / (sin(time3)));

	//�κ��� ���� �������� ���� ǥ��
	glPushMatrix();
	glTranslatef(0.0, 0.5, 0.0);
	DrawAndroid();
	glutSwapBuffers();
}

void Show()
{
	sndPlaySound(TEXT("C:\\sample4.wav"), SND_ASYNC | SND_NOSTOP);
	glLoadIdentity();

	L_Arm_x = (-40) + sin(time2) * 60;
	R_Arm_x = (-80) - L_Arm_x;
	R_Arm_y = -fabs(cos(time2) * 10);
	L_Arm_y = -fabs(-cos(time2) * 10);
	R_Leg_y = fabs(-sin(time) * 30 - 30);
	L_Leg_y = fabs(sin(time) * 30 - 30);
	R_Leg_x = sin(time) * 60;
	L_Leg_x = -R_Leg_x;

	cyl = gluNewQuadric();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);


	DrawGround();
	glLoadIdentity();
	glRotatef(-230.0, 0, 1, 0);
	glRotatef(sin(time) * 7, 0, 0, 1);
	glRotatef(sin(time) * 7, 0, 1, 0);
	
	glTranslatef(0.0, 0.18, 0.0);
	glRotatef(80, 1, 0, 0);
	glTranslatef(0.0, 0.5, 0.0);
	glPushMatrix();
	DrawBody(0, 0, 0, 0);
	glPopMatrix();
	glPushMatrix();

	DrawNeck();
	glPopMatrix();
	glPushMatrix();

	glRotatef(-75, 1, 0, 0);
	glTranslatef(0.0, -0.02, 0.0);
	DrawHead();
	glPopMatrix();
	glPushMatrix();

	DrawR_Arm((R_Arm_y + 30), 1, 0, 0);
	DrawR_Hand(-(R_Arm_y - 15), 1, 0, 0);
	glPopMatrix();
	glPushMatrix();

	glTranslatef(0.0, -0.16, -0.04);
	glRotatef(40, 0, 0, 1);
	DrawL_Arm((L_Arm_y + 30), 1, 0, 0);
	DrawL_Hand(-(L_Arm_y - 15), 1, 0, 0);
	glPopMatrix();
	glPushMatrix();

	glTranslatef(0.0, -0.45, -0.25);
	glRotatef(-90, 1, 0, 0);
	DrawL_Legs(-30, 1, 0, 0);
	DrawL_foot(10, 1, 0, 0);
	glPopMatrix();
	glPushMatrix();

	glTranslatef(0.0, -0.5, -0.5);
	glRotatef(-90, 1, 0, 0);
	DrawL_Legs(160, 1, 0, 0);
	DrawL_foot(R_Leg_y, 1, 0, 0);
	glPopMatrix();
	glutSwapBuffers();
}
void SpinShow()
{
	sndPlaySound(TEXT("C:\\sample4.wav"), SND_ASYNC | SND_NOSTOP);
	glLoadIdentity();

	L_Arm_x = (-40) + sin(time2) * 60;
	R_Arm_x = (-80) - L_Arm_x;
	R_Arm_y = -fabs(cos(time2) * 10);
	L_Arm_y = -fabs(-cos(time2) * 10);
	R_Leg_y = fabs(-sin(time) * 30 - 30);
	L_Leg_y = fabs(sin(time) * 30 - 30);
	R_Leg_x = sin(time) * 60;
	L_Leg_x = -R_Leg_x;

	cyl = gluNewQuadric();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);

	StopGround();
	glLoadIdentity();
	glRotatef((GLfloat)x, 0, 1, 0);

	glTranslatef(0.0, 0.18, 0.0);
	glRotatef(80, 1, 0, 0);
	glTranslatef(0.0, 0.5, 0.0);
	glPushMatrix();
	DrawBody(0, 0, 0, 0);
	glPopMatrix();
	glPushMatrix();

	DrawNeck();
	glPopMatrix();
	glPushMatrix();

	glRotatef(-75, 1, 0, 0);
	glTranslatef(0.0, -0.02, 0.0);
	DrawHead();
	glPopMatrix();
	glPushMatrix();

	DrawR_Arm((R_Arm_y + 30), 1, 0, 0);
	DrawR_Hand(-(R_Arm_y - 15), 1, 0, 0);
	glPopMatrix();
	glPushMatrix();

	glTranslatef(0.0, -0.16, -0.04);
	glRotatef(40, 0, 0, 1);
	DrawL_Arm((L_Arm_y + 30), 1, 0, 0);
	DrawL_Hand(-(L_Arm_y - 15), 1, 0, 0);
	glPopMatrix();
	glPushMatrix();

	glTranslatef(0.0, -0.45, -0.25);
	glRotatef(-90, 1, 0, 0);
	DrawL_Legs(0, 1, 0, 0);
	DrawL_foot(10, 1, 0, 0);
	glPopMatrix();
	glPushMatrix();

	glTranslatef(0.0, -0.5, -0.5);
	glRotatef(-90, 1, 0, 0);
	DrawL_Legs(160, 1, 0, 0);
	DrawL_foot(R_Leg_y, 1, 0, 0);
	glPopMatrix();
	glutSwapBuffers();
}

void Rocket()
{
	sndPlaySound(TEXT("C:\\sample4.wav"), SND_ASYNC | SND_NOSTOP);
	glLoadIdentity();

	L_Arm_x = -90;
	R_Arm_x = -90;
	R = 2 * fabs(-sin(time2)*0.2 - 0.2) + 0.2;
	R2 = 2 * fabs(sin(time)*0.2 - 0.2) + 0.2;
	R_Leg_y = fabs(-sin(time) * 30 - 30);
	L_Leg_y = fabs(sin(time) * 30 - 30);
	R_Leg_x = sin(time) * 60;
	L_Leg_x = -R_Leg_x;

	cyl = gluNewQuadric();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);

	DrawGround();
	glLoadIdentity();
	glRotatef(-230.0, 0, 1, 0);
	glRotatef(-fabs(sin(time) * 8), 1, 0, 0);
	glRotatef(sin(time) * 7, 0, 0, 1);

	float d = 0;
	d = fabs(sin(time)*0.08);
	glTranslatef(0.0, d, 0);
	glTranslatef(0.0, 0.5, 0.0);
	DrawAndroid();
	glutSwapBuffers();

}
void MyKeyboard(unsigned char KeyPressed, int x, int y)
{
	switch (KeyPressed)
	{
	case 'w':
		flag = 1;
		break;
	case 's':
		flag = 0;
		break;
	case 'q':
		key = 6;
		break;
	}
}

void MyDisplay()
{

	if (key == RUN)
	{
		Run();
		glPopMatrix();
	}
	else if (key == JAP)
	{
		Jap();
		glPopMatrix();
	}
	else if (key == ROCKET)
	{
		Rocket();
		glPopMatrix();
	}
	else if (key == YUNA)
	{
		Show();
		glPopMatrix();
	}
	else if (key == SPIN)
	{
		SpinShow();
		glPopMatrix();
	}
	else if (key == 6)
	{
		sndPlaySound(NULL, SND_ASYNC);
	}
	else if (key == EXIT)
	{
		ex();
		glPopMatrix();
	}
}

void MyTimer(int Value)
{
	x = (x + 20) % 360;
	time = time + 0.1;
	time2 = time2 + 0.5;
	time3 = time3 + 0.01;

	time4 = time4 + 1.0;
	glutPostRedisplay();
	glutTimerFunc(40, MyTimer, 1);
}

void MyMainMenu(int entryID)
{
	key = entryID;
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(800, 800);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("+Spin Robot");
	glInit();
	GLint MyMainMenuID = glutCreateMenu(MyMainMenu);
	glutAddMenuEntry("Run", 1);
	glutAddMenuEntry("Jap", 2);
	glutAddMenuEntry("Shoot", 3);
	glutAddMenuEntry("Skate", 4);
	glutAddMenuEntry("Spin", 5);
	glutAddMenuEntry("Stop", 6);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutKeyboardFunc(MyKeyboard);
	glutTimerFunc(40, MyTimer, 1);

	glutDisplayFunc(MyDisplay);


	glutMainLoop();
	return 0;
}