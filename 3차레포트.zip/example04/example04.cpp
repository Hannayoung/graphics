#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>

int num = 0;

void MyDisplay() {
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glViewport(0, 0, 300, 300);


	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);
	glVertex3f(-0.3, 0.3, 0.0);
	glVertex3f(-0.3, -0.3, 0.0);
	glVertex3f(0.3, 0.0, 0.0);
	glEnd();


	if (num == 1)
	{
		glClear(GL_COLOR_BUFFER_BIT);

		glViewport(0, 0, 300, 300);

		glLoadIdentity();
		
		glColor3f(1.0, 0.0, 0.0);
		
		glTranslatef(0.5, 0.0, 0.0);
		glRotatef(90.0, 1.0, 1.0, 1.0);
		glutWireCube(0.3);
	}
	if (num == 2)
	{
		glClear(GL_COLOR_BUFFER_BIT);

		glViewport(0, 0, 300, 300);

		glLoadIdentity();
	
		glColor3f(1.0, 0.0, 0.0);
		
		glRotatef(90.0, 1.0, 1.0, 1.0);
		glTranslatef(0.5, 0.0, 0.0);
		glutWireCube(0.3);
	}
	if (num == 3)
	{
		glClear(GL_COLOR_BUFFER_BIT);
		glViewport(0, 0, 300, 300);
		glLoadIdentity();
		glColor3f(1.0, 0.0, 0.0);
		
		glRotatef(90.0, 1.0, 1.0, 1.0);
		glTranslatef(0.5, 0.0, 0.0);
		glutSolidCube(0.3);
	}
	if (num == 4)
	{
		glClear(GL_COLOR_BUFFER_BIT);
		glViewport(0, 0, 300, 300);
		glLoadIdentity();
		glColor3f(1.0, 0.0, 0.0);
		
		glTranslatef(0.5, 0.0, 0.0);
		glRotatef(90.0, 1.0, 1.0, 1.0);
		glutSolidCube(0.3);
	}

	glFlush();
}

void MyMainMenu(int entryID) {
	if (entryID == 1)
		num = 1;
	else if (entryID == 2)
		num = 2;
	else if (entryID == 3)
		num = 3;   
	else if (entryID == 4)
		num = 4;
	glutPostRedisplay();
}


int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);
	glutInitWindowSize(300, 300);
	glutInitWindowPosition(550, 200);
	glutCreateWindow("Click the Start Button_Transformation");
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
	GLint MyMainMenuID = glutCreateMenu(MyMainMenu);
	glutAddMenuEntry("WireCube down", 1);
	glutAddMenuEntry("WireCube up", 2);
	glutAddMenuEntry("SolidCube up", 3);
	glutAddMenuEntry("SolidCube down", 4);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutDisplayFunc(MyDisplay);
	
	glutMainLoop();
	return 0;
}
