#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>

static int DaySun = 0, DayMercury = 0, DayVenus = 0, DayEarth = 0, DayMars = 0, Time = 0;

void MyDisplay() {
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity(); //��ǥ �ʱ�ȭ
	gluLookAt(0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0);

	//�¾�
	glRotatef((GLfloat)DaySun, 0.0, 1.0, 0.0);
	glColor3f(1.0, 0.3, 0.3);
	glutWireSphere(0.16, 20, 16);

	//����
	glLoadIdentity();
	gluLookAt(0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.06, 0.06, -1.0);
	glPushMatrix();
	glRotatef((GLfloat)DayEarth, 0.0, 1.0, 0.0);
	glTranslatef(0.25, 0.0, 0.0);
	glRotatef((GLfloat)Time, 0.0, 1.0, 0.0);
	glColor3f(0.6, 0.6, 0.6);
	glutWireSphere(0.05, 10, 8);
	glPopMatrix();

	//�ݼ�
	glLoadIdentity();
	gluLookAt(0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.08, 0.08, -1.0);
	glPushMatrix();
	glRotatef((GLfloat)Time, 0.0, 1.0, 0.0);
	glTranslatef(0.37, 0.0, 0.0);
	glColor3f(0.8, 0.2, 0.5);
	glutWireSphere(0.06, 10, 8);
	glPopMatrix();

	//����
	glLoadIdentity();
	gluLookAt(0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.1, 0.1, -1.0);
	glPushMatrix();
	glRotatef((GLfloat)DayEarth, 0.0, 1.0, 0.0);
	glTranslatef(0.6, 0.0, 0.0);
	glRotatef((GLfloat)Time, 0.0, 1.0, 0.0);
	glColor3f(0.5, 0.6, 0.7);
	glutWireSphere(0.08, 10, 8);

	//��
	glPushMatrix();
	glRotatef((GLfloat)Time, 0.0, 1.0, 0.0);
	glTranslatef(0.16, 0.0, 0.0);
	glColor3f(0.9, 0.8, 0.2);
	glutWireSphere(0.04, 10, 8);
	glPopMatrix();
	glPopMatrix();

	//ȭ��
	glLoadIdentity();
	gluLookAt(0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.1, 0.1, -1.0);
	glPushMatrix();
	glRotatef((GLfloat)DayMars, 0.0, 1.0, 0.0);
	glTranslatef(0.9, 0.0, 0.0);
	glRotatef((GLfloat)Time, 0.0, 1.0, 0.0);
	glColor3f(0.7, 0.1, 0.5);
	glutWireSphere(0.05, 10, 8);
	glPopMatrix();
	glutSwapBuffers();
}

void MyTimer(int value) {
	DaySun = (DaySun + 20) % 360;
	glutPostRedisplay();
	DayMercury = (DayMercury + 80) % 360; ;
	glutPostRedisplay();
	DayVenus = (DayVenus + 20) % 360; ;
	glutPostRedisplay();
	DayEarth = (DayEarth + 15) % 360;
	glutPostRedisplay();
	glutPostRedisplay();
	DayMars = (DayMars + 13) % 360;
	glutPostRedisplay();
	Time = (Time + 30) % 360;
	glutTimerFunc(1000, MyTimer, 1);
}

void MyReshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glClearColor(1.0, 1.0, 1.0, 0.0);
	GLfloat WidthFactor = (GLfloat)w / (GLfloat)500;
	GLfloat HeightFactor = (GLfloat)h / (GLfloat)500;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0 * WidthFactor, 1.0 * WidthFactor,
		-1.0 * HeightFactor, 1.0 * HeightFactor, -1.0, 1.0);

}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(600, 600);
	glutInitWindowPosition(410, 100);
	glutCreateWindow("Sun,Mercury,Venus, Earth, Mars");
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
	glutDisplayFunc(MyDisplay);
	glutReshapeFunc(MyReshape);
	glutTimerFunc(1000, MyTimer, 1);
	glutMainLoop();
	return 0;
}
