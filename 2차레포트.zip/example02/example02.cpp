
#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>


int MyListID;
GLuint listOne; 
GLuint listTwo;
GLuint listThree;
GLuint listFour;



void MyCreateList() {
	
	
	listOne = glGenLists(4);
	listOne = MyListID + 1;
	listTwo = listOne + 1;
	listThree = listTwo + 1;
	glNewList(listOne, GL_COMPILE_AND_EXECUTE);

	glColor3f(0.6, 0.0, 0.6);
	glBegin(GL_POLYGON);
	glVertex3f(0.14, 0.2, 0.0);
	glVertex3f(0.4, 0.2, 0.0);
	glVertex3f(0.24, -0.05, 0.0);
	glVertex3f(0.3, -0.34, 0.0);
	glVertex3f(0.0, -0.2, 0.0);
	glVertex3f(-0.3, -0.34, 0.0);
	glVertex3f(-0.24, -0.05, 0.0);
	glVertex3f(-0.4, 0.2, 0.0);
	glVertex3f(-0.14, 0.2, 0.0);
	glVertex3f(0.0, 0.48, 0.0);
	glEnd();
	
	glEndList();
	glFlush();
}


void MyDisplay() {
	glClear(GL_COLOR_BUFFER_BIT);
	glViewport(0, 0, 300, 300);
	glCallList(listOne);
	glEndList();
	glFlush();
}


int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB);
	glutInitWindowSize(300, 300);
	glutInitWindowPosition(530, 250);
	glutCreateWindow("Display List");
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, 1.0, -1.0);
	glutDisplayFunc(MyDisplay);

	MyCreateList();
	glutMainLoop();
	return 0;
}
