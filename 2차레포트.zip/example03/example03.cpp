#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <STDLIB.H>
int FlatShaded = 0 , Wireframed = 0;

int ViewX = 0, ViewY = 0;

void InitLight()
{
	GLfloat mat_diffuse[] = { 0.5, 0.4 , 0.3, 1.0 };
	GLfloat mat_specular[] = { 1.0, 1.0 , 1.0, 1.0 };
	GLfloat mat_ambient[] = { 0.5, 0.4 , 0.3, 1.0 };
	GLfloat mat_shininess[] = { 15.0 };
	GLfloat light_specular[] = { 1.0, 1.0 , 1.0, 1.0 };
	GLfloat light_diffuse[] = { 0.8, 0.8 , 0.8, 1.0 };
	GLfloat light_ambient[] = { 0.3, 0.3 , 0.3, 1.0 };
	GLfloat light_position[] = { -3, 6, 3.0, 0.0 };
	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

}




void MyMouseMove(GLint X, GLint Y)
{
	ViewX = X;
	ViewY = Y;
	glutPostRedisplay();
}

void MyKeyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'q': case 'Q' :case '|033':
		exit(0);
		break;
	case 'S' :
		if (FlatShaded)
		{
			FlatShaded = 0;
			glShadeModel(GL_SMOOTH);
		}
		else
		{
			FlatShaded = 1;
			glShadeModel(GL_FLAT);
		}

		glutPostRedisplay();
		break;

	case 'a': case 'A':
		if (Wireframed) {
			Wireframed = 0;
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		}
		else {
			Wireframed = 1;
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		}
		glutPostRedisplay();
		break;

	}
}



void MyDisplay()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	gluLookAt(0.0, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0, 1.0, 0.0);
	glRotatef(ViewX, 0.2f, 0.0f, 0.0f);
	glRotatef(ViewY, 0.0f, 0.2f, 0.0f);
	glutSolidTeapot(0.2);
	

	//���� �պκ� �����
	glBegin(GL_POLYGON);
	glVertex3f(0.35, 0.1, 0.1);
	glVertex3f(0.4, -0.2, 0.1);
	glVertex3f(0.45, -0.2, 0.1);
	glVertex3f(0.5, 0.1, 0.1);
	glEnd();

	//���� ���� ���κ� �����
	glBegin(GL_POLYGON);
	glVertex3f(0.35, 0.1, -0.1);
	glVertex3f(0.4, -0.2, -0.1);
	glVertex3f(0.4, -0.2, 0.1);
	glVertex3f(0.35, 0.1, 0.1);
	glEnd();

	//���� ������ ���κ� �����
	glBegin(GL_POLYGON);
	glVertex3f(0.45, -0.2, -0.1);
	glVertex3f(0.5, 0.1, -0.1);
	glVertex3f(0.5, 0.1, 0.1);
	glVertex3f(0.45, -0.2, 0.1);
	glEnd();

	//���� �޺κ� �����
	glBegin(GL_POLYGON);
	glVertex3f(0.35, 0.1, -0.1);
	glVertex3f(0.4, -0.2, -0.1);
	glVertex3f(0.45, -0.2, -0.1);
	glVertex3f(0.5, 0.1, -0.1);
	glEnd();

	glBegin(GL_POLYGON);
	//Ź�� ���κ��� �պκ� �����
	glVertex3f(-0.7, -0.14, 0.5);
	glVertex3f(-0.7, -0.3, 0.5);
	glVertex3f(0.7, -0.3, 0.5);
	glVertex3f(0.7, -0.14, 0.5);
	glEnd();

	glBegin(GL_POLYGON);
	//Ź�� ���κ��� ������ �κ� �����
	glVertex3f(-0.7, -0.14, 0.5);
	glVertex3f(-0.7, -0.14, -0.5);
	glVertex3f(0.7, -0.14, -0.5);
	glVertex3f(0.7, -0.14, 0.5);
	glEnd();

	glBegin(GL_POLYGON);
	//Ź�� ���κ��� �޺κ� �����
	glVertex3f(-0.7, -0.14, -0.5);
	glVertex3f(-0.7, -0.3, -0.5);
	glVertex3f(0.7, -0.3, -0.5);
	glVertex3f(0.7, -0.14, -0.5);
	glEnd();
	
	
	//Ź�� ���κ��� ���� �κ� �����


	glBegin(GL_POLYGON);
	glVertex3f(-0.7, -0.14, -0.5);
	glVertex3f(-0.7, -0.3, -0.5);
	glVertex3f(-0.7, -0.3, 0.5);
	glVertex3f(-0.7, -0.14, 0.5);
	glEnd();
	
	//Ź�� ���κ��� ������ �κ� �����


	glBegin(GL_POLYGON);
	glVertex3f(0.7, -0.14, -0.5);
	glVertex3f(0.7, -0.3, -0.5);
	glVertex3f(0.7, -0.3, 0.5);
	glVertex3f(0.7, -0.14, 0.5);
	glEnd();


	//Ź�� ���� ���ʱ�� �����

	
	glBegin(GL_POLYGON);
	glVertex3f(-0.7, -0.3, 0.4);
	glVertex3f(-0.6, -0.3, 0.4);
	glVertex3f(-0.6, -0.7, 0.4);
	glVertex3f(-0.7, -0.7, 0.4);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(-0.7, -0.3, 0.5);
	glVertex3f(-0.6, -0.3, 0.5);
	glVertex3f(-0.6, -0.7, 0.5);
	glVertex3f(-0.7, -0.7, 0.5);
	glEnd();


	glBegin(GL_POLYGON);
	glVertex3f(-0.7, -0.3, 0.4);
	glVertex3f(-0.6, -0.3, 0.4);
	glVertex3f(-0.6, -0.7, 0.4);
	glVertex3f(-0.7, -0.7, 0.4);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(-0.7, -0.3, 0.4);
	glVertex3f(-0.7, -0.3, 0.5);
	glVertex3f(-0.7, -0.7, 0.5);
	glVertex3f(-0.7, -0.7, 0.4);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(-0.6, -0.3, 0.4);
	glVertex3f(-0.6, -0.3, 0.5);
	glVertex3f(-0.6, -0.7, 0.5);
	glVertex3f(-0.6, -0.7, 0.4);
	glEnd();

	glBegin(GL_POLYGON);
	//Ź�� ���� ���ʱ�� �����
	glVertex3f(-0.7, -0.3, -0.5);
	glVertex3f(-0.6, -0.3, -0.5);
	glVertex3f(-0.6, -0.7, -0.5);
	glVertex3f(-0.7, -0.7, -0.5);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(-0.7, -0.3, -0.4);
	glVertex3f(-0.6, -0.3, -0.4);
	glVertex3f(-0.6, -0.7, -0.4);
	glVertex3f(-0.7, -0.7, -0.4);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(-0.7, -0.3, -0.5);
	glVertex3f(-0.7, -0.3, -0.4);
	glVertex3f(-0.7, -0.7, -0.4);
	glVertex3f(-0.7, -0.7, -0.5);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(-0.6, -0.3, -0.5);
	glVertex3f(-0.6, -0.3, -0.4);
	glVertex3f(-0.6, -0.7, -0.4);
	glVertex3f(-0.6, -0.7, -0.5);
	glEnd();

	glBegin(GL_POLYGON);
	//Ź���� �� ������ ��� �����
	glVertex3f(0.7, -0.3, 0.4);
	glVertex3f(0.6, -0.3, 0.4);
	glVertex3f(0.6, -0.7, 0.4);
	glVertex3f(0.7, -0.7, 0.4);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(0.7, -0.3, 0.5);
	glVertex3f(0.6, -0.3, 0.5);
	glVertex3f(0.6, -0.7, 0.5);
	glVertex3f(0.7, -0.7, 0.5);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(0.6, -0.3, 0.4);
	glVertex3f(0.6, -0.3, 0.5);
	glVertex3f(0.6, -0.7, 0.5);
	glVertex3f(0.6, -0.7, 0.4);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(0.7, -0.3, 0.4);
	glVertex3f(0.7, -0.3, 0.5);
	glVertex3f(0.7, -0.7, 0.5);
	glVertex3f(0.7, -0.7, 0.4);
	glEnd();

	//Ź���� �� ������ ��� �����

	glBegin(GL_POLYGON);
	glVertex3f(0.7, -0.3, -0.4);
	glVertex3f(0.6, -0.3, -0.4);
	glVertex3f(0.6, -0.7, -0.4);
	glVertex3f(0.7, -0.7, -0.4);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(0.7, -0.3, -0.5);
	glVertex3f(0.6, -0.3, -0.5);
	glVertex3f(0.6, -0.7, -0.5);
	glVertex3f(0.7, -0.7, -0.5);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(0.6, -0.3, -0.5);
	glVertex3f(0.6, -0.3, -0.4);
	glVertex3f(0.6, -0.7, -0.4);
	glVertex3f(0.6, -0.7, -0.5);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex3f(0.7, -0.3, -0.5);
	glVertex3f(0.7, -0.3, -0.4);
	glVertex3f(0.7, -0.7, -0.4);
	glVertex3f(0.7, -0.7, -0.5);
	glEnd();

	glFlush();


}



void MyReshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glClearColor(1.0, 1.0, 1.0, 0.0);
	GLfloat WidthFactor = (GLfloat)w / (GLfloat)500;
	GLfloat HeightFactor = (GLfloat)h / (GLfloat)500;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0 * WidthFactor, 1.0 * WidthFactor,
		-1.0 * HeightFactor, 1.0 * HeightFactor, -1.0, 1.0);

}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA | GLUT_DEPTH);

	glutInitWindowSize(500, 500);
	glutInitWindowPosition(450, 150);

	glutCreateWindow("teapot on the table");
	InitLight();
	glutDisplayFunc(MyDisplay);
	glutKeyboardFunc(MyKeyboard);
	glutMotionFunc(MyMouseMove);
	glutReshapeFunc(MyReshape);
	glutMainLoop();
}

