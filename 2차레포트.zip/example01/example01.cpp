#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <time.h>
#include <GL/glu.h>


GLfloat cubeRotate = 60.0;


GLfloat MyVertices[8][3] = {
	{ -0.5, -0.5, 0.5 },
	{ -0.5, 0.5, 0.5 },
	{ 0.5, 0.5, 0.5 },
	{ 0.5, -0.5, 0.5 },
	{ -0.5, -0.5, -0.5 },
	{ -0.5, 0.5, -0.5 },
	{ 0.5, 0.5, -0.5 },
	{ 0.5, -0.5, -0.5 }
};
GLfloat MyColors[8][3] = {
	
	{ 0.0, 0.0, 1.0 },
	{ 1.0, 0.0, 1.0 },
	{ 1.0, 1.0, 1.0 },
	{ 0.0, 1.0, 1.0 },
	{ 0.2, 0.2, 0.2 },
	{ 1.0, 0.0, 0.0 },
	{ 1.0, 1.0, 0.0 },
	{ 0.0, 1.0, 0.0 }
};
GLubyte MyVertexList[24] = {

	0, 1, 2, 3,
	0, 3, 7, 4,
	1, 5, 6, 2,
	2, 6, 7, 3,
	4, 7, 6, 5,
	0, 4, 5, 1
};

void MyDisplay() {
	glClear(GL_COLOR_BUFFER_BIT);
	glFrontFace(GL_CW);
	glEnable(GL_CULL_FACE);
	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
	glColorPointer(3, GL_FLOAT, 0, MyColors);
	glVertexPointer(3, GL_FLOAT, 0, MyVertices);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glRotatef(cubeRotate, 1.0f, 0.5f, 0.5f);

	for (GLint i = 0; i < 6; i++) {
		glDrawElements(GL_POLYGON, 4, GL_UNSIGNED_BYTE, &MyVertexList[4 * i]);
	}
	glFlush();
}

void RotateCube(int value) {
	
	cubeRotate += 1.0;
	glutPostRedisplay();
	glutTimerFunc(40, RotateCube, 1);

}

void MyReshape(int NewWidth, int NewHeight) {
	glViewport(0, 0, NewWidth, NewHeight);
	GLfloat WidthFactor = (GLfloat)NewWidth / (GLfloat)300;
	GLfloat HeightFactor = (GLfloat)NewHeight / (GLfloat)300;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0 * WidthFactor, 1.0 * WidthFactor,
		-1.0 * HeightFactor, 1.0 * HeightFactor, -1.0, 1.0);
}


int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB);
	glutInitWindowSize(300, 300);
	glutInitWindowPosition(550, 200);
	glutCreateWindow("colorful cube");
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
	glutDisplayFunc(MyDisplay);
	glutReshapeFunc(MyReshape);
	glutTimerFunc(40, RotateCube, 1);
	glutMainLoop();
	return 0;
}
