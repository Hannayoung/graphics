
#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>

static int time = 0 , Sphere =0;

void MyDisplay() {
	glClear(GL_COLOR_BUFFER_BIT);
	glRotatef((GLfloat)Sphere, 0.0, 1.0, 0.0);
	glColor3f(1.0, 0.0, 0.6);
	
	glutWireSphere(1.0 , 20.0 , 20.0);
	glFlush();
}

void MyReshape(int w, int h) {
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(30, (GLdouble)w / (GLdouble)h, 1.0, 50.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(5.0, 5.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	glutPostRedisplay();
}
void MyTimer(int value)
{
	Sphere = (Sphere + 20) % 360;
	glutPostRedisplay();
	time = (time + 30) % 360;
	glutTimerFunc(1000, MyTimer, 1);
}

int main(int argc, char** argv) {
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(450, 150);
	glutCreateWindow("Structure Defoming Transformation");
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glutDisplayFunc(MyDisplay);
	glutReshapeFunc(MyReshape);
	glutTimerFunc(1000, MyTimer, 1);
	glutMainLoop();
	return 0;
}
