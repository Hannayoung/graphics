
#include "stdafx.h"
#include <time.h>
#include <STDLIB.H> 
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>			
#include <stdio.h>

#define PI 3.1415265359
#define RandomFactor 2.0	
//zero for perfect physical

GLint ListNum;  

GLfloat OuterRadius = 1.2;
GLfloat InnerRadius = 1.0;
GLint NumOfVerticesStone = 32;    
GLfloat StoneHeight = 0.5;
GLfloat WaterHeight = 0.45;

GLint Turned = 0;
bool DoTurn = true;
bool DoMoveUp = true;
bool DoUpdateScene = true;
GLfloat MoveUp = 0.8;
GLfloat ChangeMoveUp = 0.01;

double w = 1280, h = 720;
double view[3] = { 2,2,12.9 };
double look[3] = { 2,2,2 };
int flag = -1;
void steps(void);
void window(void);

void tgate(void);
void gate(void);
double angle = 0, speed = 5, maino = 0, romo = 0, tro = 0, mgo = 0, sgo = 0;
//declarating quadric objects
GLUquadricObj *Cylinder;
GLUquadricObj *Disk;

struct tm *newtime;
time_t ltime;

GLfloat angle1;


void steps(void)
{
	int i;
	GLfloat	ambient1[] = { 0.7,0,0,1 };
	GLfloat specular1[] = { 0.7,0,0,1 };
	GLfloat diffuse1[] = { 0.7,0.0,0.0,1 };
	GLfloat mat_shininess[] = { 5000000 };


	glPushMatrix();

	glPushMatrix();
	glRotated(1, -180, 0, 0);
	glTranslated(0.1, 3.87, 4);
	glScaled(1, 1, 2);
	glutSolidCube(1);
	glPopMatrix();
	glTranslated(-.25, .1, .2);
	for (i = 0; i<19; i++)
	{
		glPushMatrix();
		glTranslated(0, i*.2, i*.2);
		glScaled(.4, .2, .3);
		glutSolidCube(1);
		glPopMatrix();
	}
	glPopMatrix();

	glPushMatrix();
	glRotated(-45, 1, 0, 0);
	glTranslated(-.45, .3, 2.7);
	glScaled(.04, 1, 5.4);
	glutSolidCube(1);
	glPopMatrix();

	

	glPushMatrix();
	glTranslated(-.45, 4, 3.6);
	glScaled(.04, .8, .75);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glTranslated(-.25, 4, 3.96);
	glScaled(.4, .8, 1.8);
	glutSolidCube(1);
	glPopMatrix();
}
void tgate(void)
{
	int i;
	GLfloat ambient1[] = { 1,.5,1,1 };
	GLfloat specular1[] = { 1,1,1,1 };
	GLfloat diffuse1[] = { .5,.5,.5,1 };
	GLfloat mat_shininess[] = { 120 };


	glPushMatrix();
	//����Ʈ �������� ����
	glTranslated(5.75 - .25, .05, 6);
	glRotated(sgo, 0, 1, 0);
	glTranslated(-5.75 + .25, -.05, -6);
	//���� ����Ʈ ��ġ ����
	glTranslated(5.75, .05, 6);
	//���� ����Ʈ�� �� ����
	glPushMatrix();
	glTranslated(0, 1.5, 0);
	glScaled(.5, .08, .08);
	glutSolidCube(1);
	glPopMatrix();
	//���� ����Ʈ�� �Ʒ� ����
	glPushMatrix();
	glTranslated(0, .05, 0);
	glScaled(.5, .08, .08);
	glutSolidCube(1);
	glPopMatrix();
	//���� ����Ʈ�� ���� ����
	glPushMatrix();
	glTranslated(-.25, .85, 0);
	glScaled(0.04, 1.7, .04);
	glutSolidCube(1);
	glPopMatrix();
	//���� ����Ʈ�� ������ ����
	glPushMatrix();
	glTranslated(.25, .8, 0);
	glScaled(.04, 1.6, .04);
	glutSolidCube(1);
	glPopMatrix();

	//��������Ʈ ����
	for (i = 1; i <= 4; i++)
	{
		glPushMatrix();
		glTranslated(-.25 + .1*i, 0, 0);
		glRotated(-90, 1, 0, 0);
		gluCylinder(Cylinder, .01, .01, 1.5, 32, 32);
		glPopMatrix();
	}

	for (i = 1; i <= 4; i++)
	{
		glPushMatrix();
		glTranslated(-.25, .05 + .3*i, 0);
		glRotated(90, 0, 1, 0);
		gluCylinder(Cylinder, .02, .02, .5, 32, 32);
		glPopMatrix();
	}
	glPopMatrix();
}
void myinit(void)
{

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-1.0, 1.0, -1 * w / h, 1 * w / h, 1, 200.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	Cylinder = gluNewQuadric();
	gluQuadricDrawStyle(Cylinder, GLU_FILL);
	gluQuadricNormals(Cylinder, GLU_SMOOTH);


	Disk = gluNewQuadric();
	gluQuadricDrawStyle(Disk, GLU_FILL);
	gluQuadricNormals(Disk, GLU_SMOOTH);
	GLfloat gam[] = { 0.2,.2,.2,1 };
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, gam);

}

void matprop(GLfloat amb[], GLfloat dif[], GLfloat spec[], GLfloat shi[])
{
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, amb);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, dif);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, spec);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, shi);
}

void wall(double thickness)
{
	glPushMatrix();
	glTranslated(2, .5*thickness, 2);
	glScaled(4.0, thickness, 4.0);
	glutSolidCube(1.0);
	glPopMatrix();
}

void wall2(double thickness)
{
	glPushMatrix();
	glTranslated(.8, .5*thickness * 4, 3.5);
	glScaled(1.6, thickness * 4, 7.0);
	glutSolidCube(1.0);
	glPopMatrix();
}

void earth(void)
{
	GLfloat ambient[] = { 1,0,0,1 };
	GLfloat specular[] = { 0,0.5,0.5,1 };
	GLfloat diffuse[] = { 0.1,0.5,0.1,1 };
	GLfloat shininess[] = { 1000 };


	matprop(ambient, diffuse, specular, shininess);
	GLfloat lightIntensity[] = { .7,.7,.7,1 };
	GLfloat light_position[] = { 2,5,-3,0 };
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightIntensity);

	glPushMatrix();
	glTranslated(0, -.25, 0);
	glScaled(100, .5, 100);
	glutSolidCube(0.5);
	glPopMatrix();
	glFlush();
}

void compound(void)
{

	GLfloat ambient[] = { 1,0,0,1 };
	GLfloat specular[] = { 0,1,1,1 };
	GLfloat diffuse[] = { .7,1,.7,1 };
	GLfloat shininess[] = { 550 };


	matprop(ambient, diffuse, specular, shininess);
	GLfloat lightIntensity[] = { 0.7,0,0.3,1 };
	GLfloat light_position[] = { 2,6,1.5,0 };
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightIntensity);

	//��Ÿ���� ���� ��
	glPushMatrix();
	glPushMatrix();
	glTranslated(-4, 0, -1 - .04);
	glRotated(90.0, 0, 0, 1);
	wall2(0.08);
	glPopMatrix();
	//��Ÿ�� ������ ��
	glPushMatrix();
	glTranslated(8, 0, -1 - .02);
	glRotated(90.0, 0, 0, 1);
	wall2(0.08);

	glPopMatrix();
	//��Ÿ�� ���� ��
	glPushMatrix();
	glTranslated(2, .8, -1);
	glRotated(-90, 1, 0, 0);
	glScaled(12, .02 * 4, 1.6);
	glutSolidCube(1.0);
	glPopMatrix();
	// ��Ÿ���� ���� ���� ��
	glPushMatrix();
	glTranslated(-3, .8, 6 - .08);
	glRotated(-90, 1, 0, 0);
	glScaled(2, .02 * 4, 1.6);
	glutSolidCube(1.0);
	glPopMatrix();
	//��Ÿ���� ���� �߰� ��
	glPushMatrix();
	glTranslated(2.5, .8, 6 - .08);
	glRotated(-90, 1, 0, 0);
	glScaled(6, .02 * 4, 1.6);
	glutSolidCube(1.0);
	glPopMatrix();
	//��Ÿ���� ���� ������ ��
	glPushMatrix();
	glTranslated(7, .8, 6 - .08);
	glRotated(-90, 1, 0, 0);
	glScaled(2, .02 * 4, 1.6);
	glutSolidCube(1.0);
	glPopMatrix();


	glPopMatrix();

	GLfloat ambient2[] = { 0,1,0,1 };
	GLfloat specular2[] = { 1,1,1,1 };
	GLfloat diffuse2[] = { .2,.6,0.1,1 };
	GLfloat shininess2[] = { 50 };
	matprop(ambient2, diffuse2, specular2, shininess2);

	//floor
	glPushMatrix();
	glTranslated(-4, -0.05, -1);
	glScaled(3, 3, 1.7);
	wall(0.08);
	glPopMatrix();

	gate();
	tgate();

	glFlush();

}

void secondFloor(void)
{
	
	GLfloat	ambient1[] = { 0.6,0,.3,.7 };
	GLfloat specular1[] = { 1,1,1,1 };
	GLfloat diffuse1[] = { 0.1,0.1,0.1,1 };
	GLfloat mat_shininess[] = { 50000 };

	matprop(ambient1, diffuse1, specular1, mat_shininess);
	glPushMatrix();
	glTranslated(0, 4, 0);
	glScaled(1, 0.1, 1);

	//���� ��
	glPushMatrix();
	glTranslated(0, 0, -.02 - .25);
	glScaled(1, 1, .95);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	//������ ��
	glPushMatrix();
	glTranslated(6 + .12, 0, -.02 - .27);
	glScaled(1, 1, 1.1);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	//�ڿ� ��
	glPushMatrix();
	glTranslated(-.08, 0, -.21);
	glScaled(1.5 + .05, 1, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	//���� ��
	glPushMatrix();
	glTranslated(-.08, 0, 4 + .11);
	glScaled(1.5 + .05, 1, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	glPushMatrix();
	glTranslated(-.04, 2, 4);
	glScaled(.08, 4, .1);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glTranslated(0, .15, 0);
	//����
	glPushMatrix();
	glTranslated(-.02 * 4, 39, -.01 * 4 - .25);
	glScaled(1.5 + .05, 80, 1.1);
	wall(0.08);
	glPopMatrix();

	GLfloat ambient2[] = { 1,0,0,1 };
	GLfloat specular2[] = { 1,1,1,1 };
	GLfloat diffuse2[] = { .7,1,0.8,1 };
	GLfloat shininess[] = { 50 };
	matprop(ambient2, diffuse2, specular2, shininess);
	
	//��
	glPushMatrix();
	glTranslated(-.02 * 3, -0.5, -.01 * 4);
	glScaled(1.5 + .01, 0, 1);
	wall(0.08);
	glPopMatrix();
	
	//���� ��
	glPushMatrix();
	glScaled(1.4 + .01, 10, 1);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	//������ ��
	glPushMatrix();
	glTranslated(6, 0, 0);
	glScaled(1.0 + .01, 10, 1);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	//���� ��
	glPushMatrix();
	glTranslated(-.08, 0, 0);
	glScaled(1.5 + .02, 10, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	//�ȿ� �� ��
	glPushMatrix();
	glTranslated(4, 0, 0);
	glScaled(1, 10, .5);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	//�ȿ� �� ��
	glPushMatrix();
	glTranslated(4.4, 0, 2);
	glScaled(.4, 10, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	//�湮 ���� ��
	glPushMatrix();
	glTranslated(4, 3, 2);
	glScaled(.11, .5, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();


	//�ȿ� ���� ���� ��
	glPushMatrix();
	glTranslated(0, 0, 2);
	glScaled(.4, 10, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	//�ȿ� ������ ���� ��
	glPushMatrix();
	glTranslated(1.6, 0, 0);
	glScaled(1, 10, .35);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();

	//������ ���� �Ա�
	glPushMatrix();
	glTranslated(1.6, 0, 2.59);
	glScaled(1, 0, .35);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	//���� ���� ���� ��
	glPushMatrix();
	glTranslated(-0.02, 30, 4);
	glScaled(.13, 3, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	//���ι��� ������ ��
	glPushMatrix();
	glTranslated(.48, 0, 4);
	glScaled(1.39, 10, 2);
	glRotated(-90.0, 1, 0, 0);
	wall(0.1);
	glPopMatrix();
	
	
	GLfloat	ambient[] = { 1,0.5,.5,1 };
	GLfloat specular[] = { 1,1,1,1 };
	GLfloat diffuse[] = { 1,.5,.5,1 };

	matprop(ambient, diffuse, specular, mat_shininess);

	GLfloat lightIntensity4[] = { 0.6,0,.3,.7 };
	GLfloat light_position4[] = { 3,1,.5,1 };
	glLightfv(GL_LIGHT6, GL_POSITION, light_position4);
	glLightfv(GL_LIGHT6, GL_DIFFUSE, lightIntensity4);
	glEnable(GL_LIGHT6);
	
	//2�� ���� ��
	glPushMatrix();
	glTranslated(0, 0, 4);
	glRotated(maino, 0, 0, 0);
	glTranslated(0, 0, -4);
	glPushMatrix();
	glTranslated(0, 0, 4);
	glScaled(.12, 8, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.04);
	glPopMatrix();

	glPushMatrix();
	glTranslated(0, 0, 4);
	glScaled(.5, 8, .2);
	glRotated(-90, 1, 0, 0);
	gluCylinder(Cylinder, 0.05, 0.05, 3, 16, 16);
	glPopMatrix();
	glPopMatrix();
	//2�� ���� ���� �Ʒ� 
	glPushMatrix();
	glTranslated(4, 0, (2 - .025));
	glRotated(romo, 0, 1, 0);
	glTranslated(-4, 0, -(2 - .025));
	glPushMatrix();
	glTranslated(4, 0, 2);
	glScaled(.099, 8, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.01);
	glPopMatrix();

	glPushMatrix();
	glTranslated(4.01, 0, 2 - .025);
	glScaled(.5, 8, .6);
	glRotated(-90, 1, 0, 0);
	gluCylinder(Cylinder, 0.05, 0.05, 3, 16, 16);
	glPopMatrix();

	glPopMatrix();
	glPopMatrix();
	glFlush();

}


void window(void)
{
	int i;
	GLfloat lightIntensity[] = { .7,0,0,1 };
	GLfloat light_position[] = { -20,4,-60,0 };
	glLightfv(GL_LIGHT1, GL_POSITION, light_position);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, lightIntensity);

	glEnable(GL_LIGHT1);

	glPushMatrix();
	glTranslated(3.185, 1, 3.95);
	//left edge of window
	glPushMatrix();
	glTranslated(.02, 1, .02);
	glScaled(.04, 2.2, .04);
	glutSolidCube(1);
	glPopMatrix();
	//right edge
	glPushMatrix();
	glTranslated(1.6 + .02, 1, 0.02);
	glScaled(.04, 2.2, .04);
	glutSolidCube(1);
	glPopMatrix();
	//top edge
	glPushMatrix();
	glTranslated(.9, 2 + .02, 0.02);
	glScaled(1.8, .04, .04);
	glutSolidCube(1);
	glPopMatrix();
	//bottom edge
	glPushMatrix();
	glTranslated(.8, .02, 0.02);
	glScaled(1.8, .04, .04);
	glutSolidCube(1);
	glPopMatrix();

	for (i = 1; i <= 3; i++)
	{

		glPushMatrix();
		glTranslated(.4*i, 0, 0);

		glRotated(-90, 1, 0, 0);
		gluCylinder(Cylinder, .01, .01, 2, 32, 32);
		glPopMatrix();
	}

	for (i = 1; i <= 3; i++)
	{
		glPushMatrix();
		glTranslated(.1 + .4*i, 0, 0);

		glRotated(-90, 1, 0, 0);
		gluCylinder(Cylinder, .01, .01, 2, 32, 32);
		glPopMatrix();
	}

	for (i = 1; i <= 4; i++)
	{
		glPushMatrix();
		glTranslated(0, .4*i, 0);

		glRotated(90, 0, 1, 0);
		gluCylinder(Cylinder, .03, .03, 1.6, 32, 32);
		glPopMatrix();
	}
	glPopMatrix();


}
void gate(void)
{
	int i;
	GLfloat	ambient1[] = { 1,.5,1,1 };
	GLfloat specular1[] = { 1,1,1,1 };
	GLfloat diffuse1[] = { .7,0,0,1 };
	GLfloat mat_shininess[] = { 120 };

	matprop(ambient1, diffuse1, specular1, mat_shininess);
	glPushMatrix();
	//if flag mgo=1 the open the main gate
	if (mgo == 1)
		glTranslated(1.5, 0, 0);
	glTranslated(-1.3, 0, 6);




	glPushMatrix();
	glTranslated(0, .05, 0);
	glScaled(1.7, 0.04, .04);
	glutSolidCube(1);
	glPopMatrix();



	for (i = 1; i <= 3; i++)
	{
		glPushMatrix();
		glTranslated(-.85, .4*i, 0);
		glRotated(90, 0, 1, 0);
		gluCylinder(Cylinder, .02, .02, 1.7, 32, 32);
		glPopMatrix();
	}
	//vertical strips of the main gate
	for (i = 1; i <= 5; i++)
	{
		glPushMatrix();
		glTranslated(-.9 + .3*i, .75, 0);
		glScaled(.2, 1.5, .02);
		glutSolidCube(1);
		glPopMatrix();
	}

	glPopMatrix();

}
void house(void)
{
	GLfloat mat_ambient[] = { 1,0,0,1 };
	GLfloat mat_specular[] = { 1,1,1,1 };
	GLfloat mat_diffuse[] = { 1,1,.7,1 };
	GLfloat mat_shininess[] = { 500000000 };

	matprop(mat_ambient, mat_diffuse, mat_specular, mat_shininess);


	GLfloat lightIntensity4[] = { 0.6,0,.3,.7 };
	GLfloat light_position4[] = { 3,1,.5,1 };
	glLightfv(GL_LIGHT6, GL_POSITION, light_position4);
	glLightfv(GL_LIGHT6, GL_DIFFUSE, lightIntensity4);
	glEnable(GL_LIGHT6);


	glPushMatrix();
	glTranslated(0, .15, 0);
	
	glPushMatrix();
	glTranslated(-.02 * 4, 3.9, -.01 * 4 - .25);
	glScaled(1.5 + .05, 1.5, 1.1);
	wall(0.08);
	glPopMatrix();


	GLfloat ambient2[] = { 1,0,0,1 };
	GLfloat specular2[] = { 1,1,1,1 };
	GLfloat diffuse2[] = { .7,1,0.8,1 };
	GLfloat shininess[] = { 50 };
	matprop(ambient2, diffuse2, specular2, shininess);

	
	glPushMatrix();
	glTranslated(-.02 * 3, -0.05, -.01 * 4);
	glScaled(1.5 + .01, 1.5, 1);
	wall(0.08);
	glPopMatrix();


	GLfloat ambient1[] = { 1,0,0,1 };
	GLfloat specular1[] = { 1,1,1,1 };
	GLfloat diffuse1[] = { 1,1,.7,1 };
	GLfloat shininess1[] = { 5000000 };
	matprop(ambient1, diffuse1, specular1, shininess1);


	
	glPushMatrix();
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(6, 0, 0);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(-.08, 0, 0);
	glScaled(1.5 + .02, 1, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(4, 0, 0);
	glScaled(1, 1, .5);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(4.4, 0, 2);
	glScaled(.4, 1, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(4, 3, 2);
	glScaled(.11, .25, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();

	glPushMatrix();
	glTranslated(0, 0, 2);
	glScaled(.4, 1, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(1.6, 0, 0);
	glScaled(1, 1, .35);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(1.6, 0, 2.59);
	glScaled(1, 1, .35);
	glRotated(90.0, 0, 0, 1);
	wall(0.08);
	glPopMatrix();

	glPushMatrix();
	glTranslated(-0.02, 3, 4);
	glScaled(.13, .27, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(.48, 0, 4);
	glScaled(.68, 1, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(4.8, 0, 4);
	glScaled(.3, 1, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(3.2, 0, 4);
	glScaled(.4, .25, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(3.2, 3.03, 4);
	glScaled(.4, .25, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.08);
	glPopMatrix();

	secondFloor();
	steps();
	window();


	GLfloat	ambient[] = { 1,0.5,.5,1 };
	GLfloat specular[] = { 1,1,1,1 };
	GLfloat diffuse[] = { 1,.5,.5,1 };
	matprop(ambient, diffuse, specular, mat_shininess);

	glPushMatrix();
	glTranslated(0, 0, 4);
	glRotated(maino, 0, 1, 0);
	glTranslated(0, 0, -4);
	glPushMatrix();
	glTranslated(0, 0, 4);
	glScaled(.12, 0.75, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.04);
	glPopMatrix();

	glPushMatrix();
	glTranslated(0, 0, 4);
	glScaled(.5, 1, .2);
	glRotated(-90, 1, 0, 0);
	gluCylinder(Cylinder, 0.05, 0.05, 3, 16, 16);
	glPopMatrix();
	glPopMatrix();
	
	glPushMatrix();
	glTranslated(4, 0, (2 - .025));
	glRotated(romo, 0, 1, 0);
	glTranslated(-4, 0, -(2 - .025));
	glPushMatrix();
	glTranslated(4, 0, 2);
	glScaled(.099, .75, 1);
	glRotated(-90.0, 1, 0, 0);
	wall(0.01);
	glPopMatrix();

	glPushMatrix();
	glTranslated(4.01, 0, 2 - .025);
	glScaled(.5, 1, .6);
	glRotated(-90, 1, 0, 0);
	gluCylinder(Cylinder, 0.05, 0.05, 3, 16, 16);
	glPopMatrix();

	glPopMatrix();
	glPopMatrix();
	glFlush();
}

void display(void)
{

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	gluLookAt(view[0], view[1], view[2], look[0], look[1], look[2], 0.0, 1.0, 0.0);
	earth();
	compound();
	house();
	glFlush();
	glutSwapBuffers();
	glutPostRedisplay();

}

void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
		//���� �ű�
	case '4':
		view[0] -= .1;
		glutPostRedisplay();
		break;
	

	case '6':
		view[0] += .1;
		glutPostRedisplay();
		break;
		

	case '7':
		view[1] += .1;
		glutPostRedisplay();
		break;
	

	case '1':
		if (view[1]>1.9)
			view[1] -= .1;
		glutPostRedisplay();
		break;
		

	case '8':
		view[2] -= .1;
		glutPostRedisplay();
		break;

	case '2':
		view[2] += .1;
		glutPostRedisplay();

		break;
	
	case 'r':
	case 'R':
		look[0] += .1;
		break;
	
	case 'l':
	case 'L':
		look[0] -= .1;
		break;
	
	case 'U':
	case 'u':
		look[1] += .1;
		break;
	
	case 'D':
	case 'd':
		look[1] -= .1;
		break;
	
	case 'f':
	case 'F':
		look[2] += .1;
		break;
		
	case 'B':
	case 'b':
		look[2] -= .1;
		break;
	
		//�� ���� �ݱ�
	case 'q':
	case 'Q':
		if (maino == 0)
			maino = 85;
		else
			maino = 0;
		break;

	case 'O':
	case 'o':
		if (romo == 0)
			romo = 75;
		else
			romo = 0;
		break;
		
	case 'p':
	case 'P':
		if (tro == 0)
			tro = 70;
		else
			tro = 0;
		break;
		//���� �� ���� �ݱ�
	case 'g':
	case 'G':
		if (mgo == 0)
			mgo = 1;
		else
			mgo = 0;
		break;
		//�������Ʈ ���� �ݱ�
	case 'h':
	case 'H':
		if (sgo == 0)
			sgo = 50;
		else
			sgo = 0;
		break;
		//�ȿ� ��� ����
	case 'i':
	case 'I':
		view[0] = 2.8;
		view[1] = 2;
		view[2] = 4.8;
		look[0] = 2.8;
		look[1] = 2;
		look[2] = 1;
		break;
		//������
	case 'T':
	case 't':
		view[0] = 6;
		view[1] = 12;
		view[2] = 10;
		look[0] = 2;
		look[1] = 4;
		look[2] = 2;
		break;
		//������
	case 'j':
	case 'J':
		view[0] = 2;
		view[1] = 2;
		view[2] = 12.9;
		look[0] = 3;
		look[1] = 2;
		look[2] = 3;
		break;
		//�ڷ�
	case 'k':
	case 'K':
		view[0] = 1;
		view[1] = 6;
		view[2] = -7;
		look[0] = 2;
		look[1] = 4;
		look[2] = 2;
		break;

	}


}

void InitLight()
{
	GLfloat global_ambient[] = { 0.1,0.1,0.1,1.0 };
	GLfloat mat_diffuse[] = { 0.5, 0.4 , 0.3, 1.0 };
	GLfloat mat_specular[] = { 1.0, 1.0 , 1.0, 1.0 };
	GLfloat mat_ambient[] = { 0.5, 0.4 , 0.3, 1.0 };
	GLfloat mat_shininess[] = { 15.0 };
	GLfloat light_specular[] = { 1.0, 1.0 , 1.0, 1.0 };
	GLfloat light_diffuse[] = { 0.8, 0.8 , 0.8, 1.0 };
	GLfloat light_ambient[] = { 0.3, 0.3 , 0.3, 1.0 };
	GLfloat light_position[] = { -3, 6, 3.0, 0.0 };
	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

}

int main(int argc, char**argv)
{
	glutInit(&argc, argv);//to initialize the glut library
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(w, h);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("house that i want in future");

	myinit();
	glutDisplayFunc(display);
	glutKeyboardFunc(Keyboard);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glClearColor(.8, .95, 1.0, 0);
	glViewport(0, 0, w, h);
	glutMainLoop();
	return 0;
}

