#include "stdafx.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>

int num = 0;
int gnum1 = 1;
int gnum2 = 1;
int gnum3 = 1;

void InitLight() {
	GLfloat mat_diffuse[] = { 0.5, 0.4, 0.3, 1.0 };
	GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_ambient[] = { 0.5, 0.4, 0.3, 1.0 };
	GLfloat mat_shininess[] = { 50.0 };
	GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_diffuse[] = { 0.8, 0.8, 0.8, 1.0 };
	GLfloat light_ambient[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat light_position[] = { -3, 2, 3.0, 0.0 };

	glShadeModel(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
}

void InitVisibility() {
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA | GLUT_DEPTH);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 0.4, 0.5, 0.0, -0.5, -1.0, 0.0, 1.0, 0.0);
	glutSolidTeapot(0.58);
	glFlush();
	
}

void InitVisibility1( int newNum)
{
	if (gnum1 < 0)
		return;
	InitVisibility();
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CW);
	glCullFace(GL_BACK);
	glDisable(GL_DEPTH_TEST);
	gnum1--;
	InitVisibility1(newNum);
}
void InitVisibility2(int newNum)
{
	if (gnum2 < 0)
		return;
	InitVisibility();
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CW);
	glCullFace(GL_BACK);
	glEnable(GL_DEPTH_TEST);
	gnum2--;
	InitVisibility2(newNum);
}

void InitVisibility3(int newNum)
{
	if (gnum3 < 0)
		return;
	InitVisibility();
	glDisable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glEnable(GL_DEPTH_TEST);
	gnum3--;
	InitVisibility3(newNum);
}

void MyDisplay() {

	InitVisibility();
	//�ĸ�����
	if (num == 1)
	{
		
		InitVisibility1(1);
		gnum1 = 1;

	}
	//�ĸ����� ��������
	if (num == 2)
	{
		InitVisibility2(1);
		gnum2 = 1;
	}
	//�������� 
	if (num == 3)
	{
		InitVisibility3(1);
		gnum3 = 1;

	}
}

void MyReshape(int w, int h) {
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 2.0);
}

void MainMenu(int entryID) {
	if (entryID == 1)
	{
		num = 1;

	}
	else if (entryID == 2)
	{
		num = 2;
	
	}
	else if (entryID == 3)
	{
		num = 3;

	}

	glutPostRedisplay();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(700, 700);
	glutInitWindowPosition(310, 0);
	glutCreateWindow("�ĸ�, ����, ������� ");
	glClearColor(0.5, 0.5, 0.5, 0.0);
	GLint MainMenuID = glutCreateMenu(MainMenu);
	glutAddMenuEntry("�ĸ����Ÿ� �Ǿ��ִ� ����", 1);
	glutAddMenuEntry("������Ű� �Ǿ��ִ� ����", 2);
	glutAddMenuEntry("�������Ÿ� �Ǿ��ִ� ����", 3);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	InitLight();
	glutDisplayFunc(MyDisplay);
	glutReshapeFunc(MyReshape);
	glutMainLoop();
	return 0;
}